[![Travis Build Status](https://magnum.travis-ci.com/dueyfinster/blackteam.svg?token=1Uqqx7ns9sdiXTgVTQTB&branch=master)](https://magnum.travis-ci.com/dueyfinster/blackteam.svg?token=1Uqqx7ns9sdiXTgVTQTB&branch=master) 
[![CircleCI Build Status](https://circleci.com/gh/dueyfinster/blackteam.png?style=shield&circle-token=2ee11936cb917c8c59911929eaeeaff3b90c6025)] (https://circleci.com/gh/dueyfinster/blackteam) 
[![Code Climate](https://codeclimate.com/repos/5565cbb169568055fe018f02/badges/0ccdae339a29dca5a244/gpa.svg)](https://codeclimate.com/repos/5565cbb169568055fe018f02/feed)


# UCD MSc Summer Practicum 2015 
Project Deployment Layout:

[![Layout Diagram](https://realpython.com/images/blog_images/dockerizing-django/container-stack.png)](https://realpython.com/images/blog_images/dockerizing-django/container-stack.png)


To get started, [Install Docker](https://github.com/dueyfinster/blackteam/wiki/Install-Docker) and follow this tutorial:

https://realpython.com/blog/python/django-development-with-docker-compose-and-machine/

## Testing
### [Unit Testing](https://github.com/dueyfinster/blackteam/wiki/Unit-Testing)
### Selenium Testing


# test kk
