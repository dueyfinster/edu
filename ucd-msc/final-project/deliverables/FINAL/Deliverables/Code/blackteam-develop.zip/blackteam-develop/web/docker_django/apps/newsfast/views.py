from django.shortcuts import render, redirect
from django.contrib.auth import logout
from django.http import HttpResponse
import os
import tweepy
import collections
from django.core.exceptions import ObjectDoesNotExist
from authomatic import Authomatic
from authomatic.adapters import DjangoAdapter
from .webapp_authproviders import CONFIG
from rest_framework import mixins, viewsets
from .models import Article, UserArticle, Job, Topic, UserTopic,TwitterFollower,RSSFeed
from .models import UserProfile, TrainingSet,NLPTechKeywordList
from .models import SystemConfig
from .serializers import JobSerializer
from .db_utils import add_user_to_db, get_keywords_from_article_body
from .db_utils import get_keywords_from_article_title
from django.views.decorators.http import require_http_methods
from redis import Redis
from docker_django.apps.newsfast.ranking import filter_articles_for_user
from .topic_form import TopicForm
from django.db.models import Count

redis = Redis(host='redis', port=6379)
# TODO Probably Django secret key to go here?
authomatic = Authomatic(CONFIG, 'XXXX')

import json
import logging
# Get an instance of a logger
logger = logging.getLogger(__name__)
version = os.environ['NEWSFAST_VERSION']


def landing(request):
    # Render the HTML template.
    return render(request, "landing.html")


def skip(request):
    request.session['skip'] = True
    return redirect('home')


def home(request):
    if 'skip' not in request.session:  # User is not logged in
        return render(request, 'landing.html')

    try: 
        systemConfig = SystemConfig.objects.get(id=1)
        num_articles_store = systemConfig.num_articles_store
        num_latest_display = systemConfig.num_latest_display
        num_personal_display = systemConfig.num_personal_display
        mix_articles = systemConfig.mix_articles
    except SystemConfig.DoesNotExist:
        # we have no object!  do something
        num_articles_store = 45
        num_latest_display = 35
        num_personal_display = 10
        mix_articles = False

    states = set_topic_states(request)
    logger.info(states.items())

    if 'twitter_id' not in request.session:  # User is not logged in
        latest_ids = Article.objects.values_list('id', flat=True).order_by('-date_published')[:num_latest_display]
        latest_feeds = Article.objects.filter(id__in=set(latest_ids))
 
        feed_ids = Article.objects.values_list('id', flat=True).order_by('-rank_score')[:num_personal_display+num_latest_display]
        personal_feeds = []
        for feed_id in feed_ids:
            if feed_id not in latest_ids:
                feed = Article.objects.get(id =feed_id)
                personal_feeds.append(feed)

        feeds = personal_feeds[:num_personal_display]

        response = render(request, 'home.html',
                      {'feeds': feeds, 'latest_feeds':latest_feeds,'topics': states,'version': version})

        return response

    # logged in user
    latest_ids = Article.objects.values_list('id', flat=True).order_by('-date_published')[:num_latest_display]
    #adding latest feeds here for demo need to refactor/do a better way than this
    latest_feeds = Article.objects.filter(id__in=set(latest_ids))

    twitter_id = request.session['twitter_id']
    ids = UserArticle.objects.values_list('article__id', flat=True).filter(
            user_profile__twitter_id=twitter_id).order_by('-rank_score', '-date')[:num_personal_display+num_latest_display]

    # feature to mix choices with default articles
    if mix_articles:
        mixed_ids = []
        ids_default = list(Article.objects.values_list('id', flat=True).order_by('-rank_score')[:num_personal_display])
        index_default = 0
        count = 0
        for id in ids:
             count = count + 1
             mixed_ids.append(id)
             if len(mixed_ids) >= num_personal_display:
                 ids = mixed_ids
                 break
             if count == 4:
                 mixed_ids.append(ids_default[index_default])
                 count = 0
                 index_default = index_default + 1

    feeds = []
    id_count = 0
    for id in ids:
         # exclude latest news from personal news
        if id not in latest_ids and id_count < num_personal_display:
             feed = Article.objects.get(id =id)
             feeds.append(feed)
             id_count = id_count + 1
    # check if user articles less than number to display and fill with highest rank default
    if id_count < num_personal_display and feeds:
        fill_ids = Article.objects.values_list('id', flat=True).order_by('-rank_score')[:num_personal_display-id_count]
        for fill_id in fill_ids:
             feed = Article.objects.get(id =fill_id)
             feeds.append(feed)
             
    if len(feeds)< 1:
         # This is a logged in user who hasn't selected topics - so give them basic Articles
        ids = Article.objects.values_list('id', flat=True).order_by('-rank_score')[:num_personal_display+num_latest_display]
        #feeds = Article.objects.filter(id__in=set(ids))

        id_count = 0
        for id in ids:
             # exclude latest news from personal news
            if id not in latest_ids and id_count < num_personal_display:
                feed = Article.objects.get(id =id)
                feeds.append(feed)
                id_count = id_count + 1

    twitter_screen_name = ''
    # include twitter screen name if user logged in
    if request.session and 'twitter_screen_name' in request.session and \
            request.session['twitter_screen_name']:
        twitter_screen_name = request.session['twitter_screen_name']

    response = render(request, 'home.html',
                      {'feeds': feeds, 'latest_feeds':latest_feeds,'topics': states,'version': version, 'twitter_screen_name': twitter_screen_name})

    return response

def set_topic_states(request):
    topics_list = Topic.objects.all()
    user_topics_list = UserTopic.objects.all()
    states = {}
    for topic in topics_list:
        states[topic.name]= 'false'
        for user_topic in user_topics_list:
            if str(topic.name) == str(user_topic.topic_name):
                states[topic.name] = 'true'
                break;
    return states

@require_http_methods(["GET", "POST"])
def user(request):
    response_data ={}
    if 'twitter_id' not in request.session:
        response_data['page']= '/login'
        return HttpResponse(json.dumps(response_data),content_type = "application/json")

    try:
        systemConfig = SystemConfig.objects.get(id=1)
        num_articles_store = systemConfig.num_articles_store
    except SystemConfig.DoesNotExist:
        # we have no object!  do something
        num_articles_store = 60

    twitter_id = request.session['twitter_id']

    set_topics_and_articles_for_user(request, twitter_id, num_articles_store)

    response_data['page']= '/'
    return HttpResponse(json.dumps(response_data),content_type = "application/json")


def set_topics_and_articles_for_user(request, twitter_id, num_articles_store):
    if request.method == 'POST':

        save_changes = request.POST.get('save_changes', "-1").strip()
        if save_changes == "1":
            selected_kws = request.POST.getlist('checkboxes[]')
            logger.info('selected kws %s' % selected_kws)

            if selected_kws:
                selected_user_topics = UserTopic.objects.filter(user_profile__twitter_id=twitter_id)\
                    .values_list('topic_name__name', flat=True)

                all_topics_alredy_covered = True
                if len(selected_kws)!= len(selected_user_topics):
                    all_topics_alredy_covered = False
                else:
                    for selected_keyword in selected_kws:
                        if selected_keyword not in selected_user_topics:
                            all_topics_alredy_covered = False
                            break

                if all_topics_alredy_covered is False:
                    UserTopic.objects.filter(user_profile__twitter_id=twitter_id).delete()
                    UserArticle.objects.filter(user_profile__twitter_id=twitter_id).delete()
                    user_profile = UserProfile.objects.get(twitter_id=twitter_id)
                    for topic_name in selected_kws:
                        # prevent duplicates - check if count in db is zero
                        topic = Topic.objects.get(name=topic_name)
                        UserTopic.objects.create(user_profile=user_profile, topic_name=topic)

                    # inline call find articles related to user topics when choices are saved
                    filter_articles_for_user(user_profile,selected_kws, num_articles_store)
            else:
                # handle case of user unselecting all keywords
                UserTopic.objects.filter(user_profile__twitter_id=twitter_id).delete()
                UserArticle.objects.filter(user_profile__twitter_id=twitter_id).delete()


def login(request):
    provider_name = 'tw'
    # We we need the response object for the adapter.
    response = HttpResponse()

    # Start the login procedure
    # this uses the authomatic library which can also be used for facebook etc
    # for twtter this will redirect user to twitter to authenticate app
    # login will then get called a 2nd time as the callback
    # TODO handle user rejecting the app when sent to twtter sign in
    result = authomatic.login(DjangoAdapter(request, response), provider_name)

    # If there is no result, the login procedure is still pending.
    # Don't write anything to the response if there is no result!
    if result:
        # If there is result,
        # the login procedure is over and we can write to response.
        response.write('<a href="..">Home</a>')

        if result.error:
            # Login procedure finished with an error.
            response.write('<h2>Ooops, there is a problem with Twitter login. We will look into it !</h2>')

        elif result.user:
            # Hooray, we have the user!

            # OAuth 2.0 and OAuth 1.0a provide only limited user data on login,
            # We need to update the user to get more info.
            if not (result.user.name and result.user.id):
                result.user.update()

            # If there are credentials (only by AuthorizationProvider),
            # we can _access user's protected resources.
            if result.user.credentials:

                # Each provider has it's specific API.
                if result.provider.name == 'tw':
                    # Insert twitter info to DB
                    kwargs = {'twitter_id': result.user.id,
                              'twitter_screen_name': result.user.name}
                    add_user_to_db(**kwargs)

                    # Keep the access token and secret for the session
                    # we will use this to setup tweepy
                    response.write('Your are logged in with Twitter.<br />')
                    response.write(result.user.credentials)
                    response.write(result.user.credentials.consumer_secret)

                    # Keep the access token and secret
                    # we will use this to setup tweepy
                    # See followers example for how to setup tweepy
                    request.session['skip'] = True
                    request.session['twitter_access_token_key'] \
                        = result.user.credentials.token
                    request.session['twitter_access_token_secret'] \
                        = result.user.credentials.token_secret
                    request.session['twitter_id'] \
                        = result.user.id
                    request.session['twitter_screen_name'] = result.user.name

                    user_topic_count = UserTopic.objects.filter(user_profile__twitter_id=result.user.id).count()

                    # if user_topic_count == 0:
                    #     return redirect('user')
                    # else:
                    return redirect('home')

    return response


def logout_user(request):
    response = HttpResponse()
    logout(request)
    response.delete_cookie('client_id')
    response.delete_cookie('authomatic')
    response.delete_cookie('sessionid')
    response.delete_cookie('csrftoken')
    return redirect('home')

'''
@require_http_methods(["GET", "POST"])
def user(request):
    if 'twitter_id' not in request.session:
        return redirect('login')

    response = HttpResponse()
    twitter_id = request.session['twitter_id']

    # Posting topics to database
    set_topics_and_articles_for_user(request, twitter_id, num_articles_store=10)

    topics = Topic.objects.all()

    twitter_screen_name = ''

    # include twitter screen name if user logged in
    if request.session and 'twitter_screen_name' in request.session and \
            request.session['twitter_screen_name']:
        twitter_screen_name = request.session['twitter_screen_name']

    user_topics = None

    try:
        user_topics = UserTopic.objects.filter(user_profile__twitter_id=twitter_id)
    except ObjectDoesNotExist:
        logging.error("No topics for this user")

    response = render(request, 'user_page.html',
                      {'topics': topics, 'user_topics': user_topics,
                       'version': version, 'form': TopicForm(),
                       'twitter_screen_name': twitter_screen_name})
    return response
'''


def article_info(request):
    response_data ={}
    twitter_widget = "<a class='twitter-timeline' href='https://twitter.com/google' data-widget-id='626889351583170560' data-screen-name='google'>Tweets by @google</a>"

    if request.method == 'POST':

        article_id = request.POST['article_id']
        response_data['article_id'] = article_id
        clicked_article = Article.objects.get(id = article_id)

        response_data['article_title']= clicked_article.title
        response_data['article_link']= clicked_article.url
        response_data['article_content']= clicked_article.summary
        response_data['rss_feed']= clicked_article.rss_feed.name
        response_data['date_published']= clicked_article.date_published.strftime("%B %d, %Y, %H:%M:%S")
        # response_data['related_tweets']= get_related_tweets(request,article_id)

        '''
        topic_keywords = get_keywords_from_article_title(article_id)
        for topic_keyword in topic_keywords:
            str_topic_keyword = topic_keyword.decode("utf-8").strip()
            if len(str_topic_keyword) > 0:
                hst_flwr = TwitterFollower.objects.values_list('name', flat=True).filter(name=str_topic_keyword.lower())
                if len(hst_flwr) > 0:
                    twitter_widget.replace('google',hst_flwr[0])
                    break
        '''

        twitter_rss = RSSFeed.objects.values_list('twitter_username', flat=True).filter(name=clicked_article.rss_feed.name)[:1]
        if twitter_rss:
                twitter_username = twitter_rss[0]
                twitter_widget = twitter_widget.replace('google',twitter_username)

        response_data['twitter_username'] = twitter_username

        if 'twitter_id' in request.session:

             if TrainingSet.objects.filter(article = clicked_article).count() < 1:

                user_id = request.session['twitter_id']
                if user_id != '':

                    user_twitter = UserProfile.objects.get(twitter_id=user_id)

                    keywords = get_keywords_from_article_body(article_id)
                    for keyword in keywords:
                        extracted_keyword = keyword.decode("utf-8").strip()

                        training_article = TrainingSet(user = user_twitter, article = clicked_article ,keyword = extracted_keyword)
                        training_article.save()

                    traning_articles_exist = TrainingSet.objects.filter(user = user_twitter).values('article')\
                                .annotate(total=Count('article')).order_by('date')

                    if traning_articles_exist.count() > 100:

                        item_to_delete = traning_articles_exist[0]
                        item_to_delete.delete()

    return HttpResponse(
        json.dumps(response_data),
        content_type = "application/json"
    )


def topics(request):
    response_data = get_topic_states(request)

    return HttpResponse(
        json.dumps(response_data),
        content_type = "application/json"
    )


def get_topic_states(request):

    logger.info("in get topic states")
    topics_list = Topic.objects.all()
    twitter_id = request.session['twitter_id']

    try:
        user_topics_list = UserTopic.objects.filter(user_profile__twitter_id=twitter_id)

        logger.info(user_topics_list)
    except ObjectDoesNotExist:
        logging.error("No topics for this user")

    response_data = collections.OrderedDict()
    for topic in topics_list:
        response_data[topic.name] = 'false'
        for user_topic in user_topics_list:
            if str(topic.name) == str(user_topic.topic_name):
                response_data[topic.name] = 'true'
                break;
    
    return response_data


def get_related_tweets(request,article_id):
    ''' fn to get tweets related to article '''
    # check is current session logged in on twitter
    twitter_list = []
    if request.session and 'twitter_screen_name' in request.session and \
            request.session['twitter_screen_name']:
        auth = tweepy.OAuthHandler(CONFIG['tw']['consumer_key'], CONFIG['tw']['consumer_secret'])
        auth.set_access_token(request.session['twitter_access_token_key'], request.session['twitter_access_token_secret'])
        api = tweepy.API(auth)

        keywords = get_keywords_from_article_title(article_id)
        topic_kws = get_topics_from_keywords(keywords)
        twitter_query = ''
        count = 0
        for keyword in topic_kws:
            keyword = '#' + keyword
            if count:
                twitter_query = twitter_query +  ' ' + keyword
            else: 
                twitter_query = keyword
            count = count + 1
        logger.info('query %s' % twitter_query)
        search_results = api.search(q=twitter_query, count=10, lang="en")
        for tweet in search_results:
            twitter_entry = tweet.user._json['screen_name'] + ':' + tweet.text
            twitter_list.append(twitter_entry)

    return twitter_list;


def get_topics_from_keywords(keywords):
    topics_list = Topic.objects.all()
    matching_topics = set() 
    for topic in topics_list:
        my_topic = str(topic.name).lower()
        for my_kw in keywords:
            my_kw = my_kw.decode("utf-8") 
            if my_topic == my_kw:
                matching_topics.add(my_topic)

    return matching_topics


class JobViewSet(mixins.CreateModelMixin,
                 mixins.ListModelMixin,
                 mixins.RetrieveModelMixin,
                 viewsets.GenericViewSet):
    """
    API endpoint that allows jobs to be viewed or created.
    """
    queryset = Job.objects.all()
    serializer_class = JobSerializer
