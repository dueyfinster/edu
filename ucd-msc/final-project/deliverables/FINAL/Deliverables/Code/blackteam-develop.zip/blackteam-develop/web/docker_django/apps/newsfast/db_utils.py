import logging

from django.core.exceptions import ObjectDoesNotExist
from redis import Redis
from .nlp_utils import NLPExtractKeywords

from .models import UserProfile, Article

# Get an instance of a logger
logger = logging.getLogger(__name__)
redis = Redis(host='redis', port=6379)


def add_user_to_db(**kwargs):
    try:
        # raises Entry.DoesNotExist
        UserProfile.objects.get(twitter_id=kwargs.get('twitter_id'))
        logger.debug('Not inserting twitter id, object already exists')
    except ObjectDoesNotExist:
        # OK to insert twitter id
        user = UserProfile.objects.create()
        user.twitter_id = kwargs.get('twitter_id', '')
        user.twitter_screen_name = kwargs.get('twitter_screen_name', '')
        user.twitter_name = kwargs.get('twitter_name', '')
        user.email_address = kwargs.get('email_address', '')
        user.linkedin_id = kwargs.get('linkedin_id', '')
        user.facebook_id = kwargs.get('facebook_id', '')
        user.save()


def db_insert_keywords(my_article_id, my_keywords, ex_type):
    if ex_type == 'title':
        art_title_key = 'art:title:' + str(my_article_id)
        for my_kw in my_keywords:
            kw_title_key = 'kw:title:' + my_kw
            # will have set of keywords with key of article
            redis.sadd(art_title_key, my_kw)
            redis.sadd('kw:title', kw_title_key)
            # will have set of articles with key of keyword
            redis.sadd(kw_title_key, my_article_id)
    else:
        art_body_key = 'art:body:' + str(my_article_id)
        for my_kw in my_keywords:
            kw_body_key = 'kw:body:' + my_kw
            # will have set of keywords with key of article
            redis.sadd(art_body_key, my_kw)
            redis.sadd('kw:body', kw_body_key)
            # will have set of articles with key of keyword
            redis.sadd(kw_body_key, my_article_id)


def update_article_keywords_extracted(my_article_id):
    try:
        # raises Entry.DoesNotExist
        my_article = Article.objects.get(id=my_article_id)
        my_article.keywords_extracted = True
        my_article.save(update_fields=['keywords_extracted'])
    except ObjectDoesNotExist:
        logger.debug('Article does not exist')


def get_keywords_from_article(article_id):
    return redis.smembers(article_id)


def get_keywords_from_article_title(article_id):
    article_id = 'art:title:' + str(article_id)
    return redis.smembers(article_id)


def get_keywords_from_article_body(article_id):
    article_id = 'art:body:' + str(article_id)
    return redis.smembers(article_id)


def get_articles_from_keyword_title(keyword):
    keyword = 'kw:title:' + keyword.lower()
    articles = redis.smembers(keyword)
    return articles


def get_articles_from_keyword_body(keyword):
    keyword = 'kw:body:' + keyword.lower()
    articles = redis.smembers(keyword)
    return articles


def get_matching_articles_for_user(user_selected_keywords):
    """ Function to return all articles which match user topic """
    articles = set()
    for my_keyword in user_selected_keywords:
        article_set = get_articles_from_keyword_title(my_keyword)
        if article_set:
            for article_id in article_set:
                articles.add(article_id)
    return articles


def get_matching_article(user_selected_keywords, my_article_id):
    """ Check if this article matches user topic """
    matched_keywords = set()
    result = False
    for my_keyword in user_selected_keywords:
        article_set = get_articles_from_keyword_title(my_keyword)
        if my_article_id in article_set:
            matched_keywords.add(my_keyword)
    if matched_keywords:
        result = True
    return result, matched_keywords

def get_matching_article_body(user_selected_keywords, my_article_id):
    """ Check if this article matches user topic """
    matched_keywords = set()
    result = False
    for my_keyword in user_selected_keywords:
        article_set = get_articles_from_keyword_body(my_keyword)
        if my_article_id in article_set:
            matched_keywords.add(my_keyword)
    if matched_keywords:
        result = True
    return result, matched_keywords


def extract_keywords_from_article(article):
    """ Extract keywords from article and store in redis """
    my_nlp = NLPExtractKeywords(article.title)
    my_keywords = my_nlp.extract_keywords()
    db_insert_keywords(article.id, my_keywords, ex_type='title')

    my_nlp = NLPExtractKeywords(article.summary)
    my_keywords = my_nlp.extract_keywords()
    db_insert_keywords(article.id, my_keywords, ex_type='body')
    # set flag in article so only extract once
    update_article_keywords_extracted(article.id)
    return True

