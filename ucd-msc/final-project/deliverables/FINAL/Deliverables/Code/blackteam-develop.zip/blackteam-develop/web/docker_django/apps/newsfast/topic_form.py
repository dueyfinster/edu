# -*- coding: utf-8 -*-
from django import forms

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Field
from crispy_forms.bootstrap import PrependedText, FormActions
from docker_django.apps.newsfast.models import Topic


class TopicForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(TopicForm, self).__init__(*args, **kwargs)
        topics = Topic.objects.all()
        lines = []
        for topic in topics:
            t = (topic.id, topic.name)
            lines.insert(0, t)

        choices = tuple(lines)
        self.fields['checkboxes'].choices = choices

    checkboxes = forms.MultipleChoiceField(
        initial='option_one',
        widget=forms.CheckboxSelectMultiple,
        help_text="<strong>Note:</strong> Please select your favourite topics.",
    )

    # Uni-form
    helper = FormHelper()
    helper.form_class = 'form-horizontal'
    helper.layout = Layout(
        Field('checkboxes', style="background: #FAFAFA; padding: 10px;"),
        PrependedText('prepended_text', '<input type="checkbox" checked="checked" value="" id="" name="">',
                      active=True),
        FormActions(
            Submit('save_changes', 'Save changes', css_class="btn-primary"),
            Submit('cancel', 'Cancel'),
        )
    )
