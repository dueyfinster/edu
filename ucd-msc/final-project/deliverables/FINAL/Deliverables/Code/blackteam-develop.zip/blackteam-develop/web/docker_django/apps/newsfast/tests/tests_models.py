from django.test import TestCase

from docker_django.apps.newsfast.models import Article, RSSFeed, Topic, \
    NLPTechKeywordList, UserTopic, UserProfile


# Create your tests here.
class RSSFeedTestCase(TestCase):
    def setUp(self):
        RSSFeed.objects.create(name="Test RSS Feed",
                               url="http://www.example.com",
                               twitter_username="sample", rank_bonus=0)

    def test_rss_feed_values_set_correctly(self):
        item = RSSFeed.objects.get(name="Test RSS Feed")
        self.assertEqual(item.url, "http://www.example.com")
        self.assertEqual(item.twitter_username, "sample")


class TopicTestCase(TestCase):
    def setUp(self):
        Topic.objects.create(name="Test Topic")

    def test_topic_values_set_correctly(self):
        item = Topic.objects.get(name="Test Topic")
        self.assertEqual(item.name, "Test Topic")


class TechKeywordListTestCase(TestCase):
    def setUp(self):
        NLPTechKeywordList.objects.create(name="Test TechKeywordList")

    def test_tech_keyword_values_set_correctly(self):
        item = NLPTechKeywordList.objects.get(name="Test TechKeywordList")
        self.assertEqual(item.name, "Test TechKeywordList")


class ArticleTestCase(TestCase):
    def setUp(self):
        rss_feed = RSSFeed.objects.create(name="Test RSS Feed",
                               url="http://www.example.com",
                               twitter_username="sample",
                                rank_bonus=0)
        Article.objects.create(title="Test Article",
                               url="http://www.example.com",
                               summary="A very nice article",
                               rss_feed=rss_feed,
                               keywords_extracted=False,
                               rank_score=10)

    def test_article_values_set_correctly(self):
        item = Article.objects.get(title="Test Article")
        self.assertEqual(item.title, "Test Article")
        self.assertEqual(item.url, "http://www.example.com")
        self.assertEqual(item.summary, "A very nice article")
        self.assertEqual(item.rss_feed.name, "Test RSS Feed")
        self.assertEqual(item.keywords_extracted, False)


class UserTopicTestCase(TestCase):
    def setUp(self):
        my_profile = UserProfile.objects.create(twitter_id="123456",
                                                twitter_screen_name="larry")
        topic = Topic.objects.create(name="Apple")
        UserTopic.objects.create(user_profile=my_profile,
                                 topic_name=topic)

    def test_user_topic_values_set_correctly(self):
        item = UserTopic.objects.filter(user_profile__twitter_id="123456").first()
        self.assertEqual(item.topic_name.name, "Apple")
        item = UserProfile.objects.get(twitter_id="123456")
        self.assertEqual(item.twitter_id, "123456")
