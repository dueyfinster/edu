from datetime import datetime
from functools import wraps
import os
import time
import csv
import logging
from decimal import Decimal

import feedparser as fd

from celery.signals import celeryd_init

from docker_django.apps.newsfast.ranking import get_user_topics, get_article_ranking, create_article_from_feed_entry, \
    create_userarticle, rank_older_articles
from docker_django.celery import app
from .models import RSSFeed, Article, Job, NLPTechKeywordList, Topic, OffensiveWord, Synonym
from .models import UserProfile,TwitterFollower
from .db_utils import get_matching_article, get_matching_article_body
from .db_utils import extract_keywords_from_article





# Get an instance of a logger
logger = logging.getLogger(__name__)
TIMEOUT = 30


def update_job(fn):
    @wraps(fn)
    def wrapper(job_id, *args, **kwargs):
        job = Job.objects.get(id=job_id)
        job.status = 'started'
        job.save()
        try:
            result = fn(*args, **kwargs)
            job.result = result
            job.status = 'finished'
            job.save()
        except:
            job.result = None
            job.status = 'failed'
            job.save()

    return wrapper


@app.task
def process_rss_feeds():
    rss_feeds = RSSFeed.objects.all()

    for rss_feed in rss_feeds:
        feeds = fd.parse(rss_feed.url)
        for entry in feeds.entries:
            if hasattr(entry, 'summary'):
                try:
                    item = create_article_from_feed_entry(entry, rss_feed)

                    if item is not None:

                        # new article has been inserted, now extract keywords
                        extract_keywords_from_article(item)

                        # for all users, check if topic matches article and add UserArticle for each match
                        userids = UserProfile.objects.values_list('twitter_id', flat=True)
                        article_id = item.id
                        article_id_string = bytes(str(item.id), 'ascii')  # python 3 boo !
                        # get article for duplicate check
                        article = Article.objects.get(id=article_id)
                        for user_id in userids:

                            # get user profile for duplicate check
                            user_profile = UserProfile.objects.get(twitter_id=user_id)

                            user_selected_keywords = get_user_topics(user_id)
                            result, matched_keywords = get_matching_article(user_selected_keywords, article_id_string)

                            if result is False:
                                result, matched_keywords = get_matching_article_body(user_selected_keywords, article_id_string)

                            if result:
                                ranking = get_article_ranking(article.id, user_id, matched_keywords)
                                ranking = Decimal(ranking) + Decimal(article.rank_score)
                                create_userarticle( ranking, user_profile, article)
                except:
                    logging.exception('Got exception on process_rss_feeds')

    return True


@app.task
@celeryd_init.connect
def import_feeds(sender=None, conf=None, **kwargs):
    time.sleep(TIMEOUT)
    if len(RSSFeed.objects.all()) is 0:
        logging.info('Going to import RSS feeds')
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/feed_list.csv')
        with open(filepath, newline='') as csvfile:
            feed_list = csv.reader(csvfile, delimiter=',')
            next(feed_list)
            for row in feed_list:
                feed = RSSFeed()

                try:
                    d = fd.parse(row[0])
                    feed.name = d.feed.title
                except AttributeError:
                    logging.error('Could not get title for:', row[0])

                feed.url = row[0]
                feed.twitter_username = row[1]
                feed.rank_bonus = row[2]
                feed.save()
        logging.info('Successfully imported feeds')
    else:
        logging.info(
            'Feeds already imported, please delete existing to reimport')


@app.task
@celeryd_init.connect
def import_topics(sender=None, conf=None, **kwargs):
    time.sleep(TIMEOUT)
    logging.info('Importing topics now...')
    if len(Topic.objects.all()) is 0:
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/topic_list.csv')
        with open(filepath, newline='') as csvfile:
            topic_list = csv.reader(csvfile, delimiter=',')
            next(topic_list)
            for row in topic_list:
                topic = Topic()
                topic.name = row[0]
                topic.save()
        logging.info('Successfully imported topics')
        process_synonyms()
    else:
        logging.info(
            'Topics already imported, please delete existing to reimport')

@app.task
@celeryd_init.connect
def import_twitter_follower(sender=None, conf=None, **kwargs):
    time.sleep(TIMEOUT)
    logging.info('Importing twitter_follower...')
    if len(TwitterFollower.objects.all()) is 0:
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/twitter_follower.csv')
        with open(filepath, newline='') as csvfile:
            twitter_follower = csv.reader(csvfile, delimiter=',')
            next(twitter_follower)
            for row in twitter_follower:
                tw_flwr = TwitterFollower()
                tw_flwr.name = row[0]
                tw_flwr.hash_tag_name=row[1]
                tw_flwr.save()
        logging.info('Successfully twitter_follower')
        process_synonyms()
    else:
        logging.info(
            'Twitter_follower already imported, please delete existing to reimport')


@app.task
@celeryd_init.connect
def import_offensive_words(sender=None, conf=None, **kwargs):
    time.sleep(TIMEOUT)
    logging.info('Importing offensive words now...')
    if len(OffensiveWord.objects.all()) is 0:
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/offensive_words.csv')
        with open(filepath, newline='') as csvfile:
            topic_list = csv.reader(csvfile, delimiter=',')
            next(topic_list)
            for row in topic_list:
                off_word = OffensiveWord()
                off_word.word = row[0]
                off_word.save()
        logging.info('Successfully imported offensive word')
    else:
        logging.info(
            'Offensive word already imported, please delete existing to reimport')


@app.task
@celeryd_init.connect
def import_tech_keywords(sender=None, conf=None, **kwargs):
    time.sleep(TIMEOUT)
    logging.info('Importing tech keywords ...')
    if not NLPTechKeywordList.objects.all():
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/tech_keyword_list.csv')
        with open(filepath, newline='') as csvfile:
            tech_list = csv.reader(csvfile, delimiter=',')
            next(tech_list)
            for row in tech_list:
                tech = NLPTechKeywordList()
                tech.name = row[0]
                tech.save()
        logging.info('Successfully imported tech list')
    else:
        logging.info(
            'Tech list already imported, '
            'please delete existing to reimport')


@app.task
def down_rank_older_articles():
    articles = Article.objects.all()
    rank_older_articles(articles)


def process_synonyms():
    if len(OffensiveWord.objects.all()) is 0:
        script_path = os.path.dirname(os.path.realpath(__file__))
        filepath = os.path.join(script_path, 'data/synonyms.csv')
        with open(filepath, newline='') as csvfile:
            synonym_list = csv.reader(csvfile, delimiter=',')
            next(synonym_list)
            for row in synonym_list:
                syn = Synonym()
                logging.info('Looking for synonyms in DB: {0}, {1}', row[0], row[1])
                topic_one = Topic.objects.get(name=row[0])
                topic_two = Topic.objects.get(name=row[1])
                syn.first_word = topic_one
                syn.second_word = topic_two
                syn.save()
                topic_one.has_synonym = True
                topic_one.save()
                topic_two.has_synonym = True
                topic_two.save()
        logging.info('Successfully imported synonyms')
    else:
        logging.info('Synonyms already imported')


TASK_MAPPING = {
    'import_feeds': import_feeds,
    'process_rss_feeds': process_rss_feeds
}

