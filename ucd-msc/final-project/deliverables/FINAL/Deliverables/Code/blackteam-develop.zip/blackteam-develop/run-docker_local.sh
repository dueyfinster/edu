#!/bin/bash

if [[ "$OSTYPE" == "darwin"* ]]; then
    eval "$(docker-machine env dev)"
fi

docker stop $(docker ps -a -q)
docker rm $(docker ps -a -q)
#docker rmi $(docker images -q)
docker-compose build
docker-compose up -d
docker-compose run web /usr/bin/python3 manage.py migrate
docker-compose run web /usr/bin/python3 manage.py createadmin
sleep 4
echo "To view log files copy/paste a line below to terminal"
echo tail -f "$(docker inspect "$(docker ps |grep blackteam_web|grep -i up|grep .... | cut -c 1-12|head -n 1)"|grep -i volume|grep -i '/var'|grep -o '/var/.*_data')""/newsfast.log"
echo tail -f "$(docker inspect "$(docker ps |grep blackteam_web|grep -i up|grep .... | cut -c 1-12|head -n 1)"|grep -i volume|grep -i '/var'|grep -o '/var/.*_data')""/django_request.log"
echo "firefox opening http://""$(docker inspect "$(docker ps |grep blackteam_web|grep -i up|grep .... | cut -c 1-12|head -n 1)"|grep -i 'ipaddress":'|grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}')":8000
firefox http://"$(docker inspect "$(docker ps |grep blackteam_web|grep -i up|grep .... | cut -c 1-12|head -n 1)"|grep -i 'ipaddress":'|grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}')":8000