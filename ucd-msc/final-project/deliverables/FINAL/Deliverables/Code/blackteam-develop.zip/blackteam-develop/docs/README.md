# Black Team Docs

Simply run ``run-notebook.sh`` to get Docker to bring up a container with
iPython (Jupyter) notebook [Python 2 & 3] and any dependencies specified in
``requirements.txt`` (such as Natural Language Toolkit [ntlk]).

You can store any notebook files here (.pynb) so the server can access them.
**Please Note** __access is read only__ - don't forget to download the .pynb
from the server when done!
