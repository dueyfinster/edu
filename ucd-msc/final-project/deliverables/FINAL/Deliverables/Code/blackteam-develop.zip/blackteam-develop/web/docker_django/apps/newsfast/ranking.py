from decimal import Decimal
import logging
import datetime
from django.core.exceptions import ObjectDoesNotExist
from django.db import IntegrityError
from docker_django.apps.newsfast.db_utils import get_keywords_from_article_body, get_matching_articles_for_user, \
    get_matching_article
from docker_django.apps.newsfast.models import UserProfile, UserTopic, Topic, TrainingSet, Article, UserArticle

SCORE_NEW_ARTICLE = Decimal(30.0)
SCORE_ARTICLE_OLDER_12H = (-10.00)
SCORE_ARTICLE_OLDER_24H = (-20.00)
SCORE_ARTICLE_OLDER_36H = (-30.00)
SCORE_ARTICLE_HAS_IMG = Decimal(50.0)
SCORE_ARTICLE_TECH_KEYWORD = Decimal(10.0)
SCORE_ARTICLE_USER_KEYWORD = Decimal(20.0)
SCORE_ARTICLE_SUMMARY_LONGER_150C = Decimal(25.0)


def rank_older_articles(articles):
    for article in articles:
        date_pub = datetime.date(article.date_published)
        original_score = Decimal(article.rank_score)

        if date_pub > datetime.timedelta(hours=12):
            article.rank_score = original_score + SCORE_ARTICLE_OLDER_12H
            article.save()
        elif date_pub > datetime.timedelta(hours=24):
            article.rank_score = original_score + SCORE_ARTICLE_OLDER_24H
            article.save()
        elif date_pub > datetime.timedelta(hours=36):
            article.rank_score = original_score + SCORE_ARTICLE_OLDER_36H
            article.save()



def get_user_topics(user_id):
    """ get all topics selected by user """
    topic_name = set()
    try:
        user_profile = UserProfile.objects.get(twitter_id=user_id)
        user_topics = UserTopic.objects.filter(user_profile__id=user_profile.id)
        for user_topic in user_topics:
            topic = Topic.objects.get(id__exact=user_topic.topic_name.id)
            topic_name.add(topic.name)
    except ObjectDoesNotExist:
        logging.error("No topics for this user")

    return topic_name


def get_article_ranking(article_id, user_id, matched_keywords):
    """ get ranking for the article """
    try:
        rank_score = 0.0

        training_set = TrainingSet.objects.filter(user__twitter_id = user_id)
        if training_set.count() > 0:

            new_keywords = get_keywords_from_article_body(article_id)
            new_keywords_lst = [v.decode("utf-8").strip() for v in new_keywords]

            training_set_article_ids = training_set.values_list('article__id', flat=True).distinct()

            for ts_article_id in training_set_article_ids:

                trn_article_keywords = TrainingSet.objects\
                                .values_list('keyword', flat=True)\
                                .filter(user__twitter_id = user_id, article__id = ts_article_id)

                match_keyword_count = 0

                for trn_article_keyword in trn_article_keywords:
                    if trn_article_keyword in new_keywords_lst:
                        match_keyword_count = match_keyword_count + 1

                    unmatched_trn_article_keywords = len(trn_article_keywords) - match_keyword_count
                    unmatched_keywords_list_ids = len( new_keywords_lst) - match_keyword_count

                    total = unmatched_trn_article_keywords + unmatched_keywords_list_ids + match_keyword_count

                    if total > 0:
                        temp_rank = (match_keyword_count / float(total)) * 100
                        if temp_rank > rank_score:
                            rank_score = temp_rank

        default_matched_keywords_count = len(matched_keywords)
        if default_matched_keywords_count > 0:
            rank_score = rank_score + (default_matched_keywords_count * 2)

    except:

        logging.exception('Set ranking')

    return rank_score


def filter_articles_for_user( user_profile, user_selected_keywords, number_of_articles):
    article_list_rds = list(get_matching_articles_for_user(user_selected_keywords))

    article_list = []
    for article_id_rds in article_list_rds:
        str_article_id =article_id_rds.decode("utf-8").strip()
        if str_article_id != 'None' and str_article_id != "":
            article_list.append(int(str_article_id))

    articles = Article.objects.filter(id__in=set(article_list)).order_by('-rank_score', '-date_published')[:number_of_articles]
    for article in articles:

        article_id_string = bytes(str(article.id), 'ascii')  # python 3 boo !

        matched_keywords = get_matching_article(user_selected_keywords, article_id_string)

        if UserArticle.objects.filter(user_profile = user_profile,article = article).count() < 1:
            ranking = get_article_ranking(article.id, user_profile.twitter_id, list(matched_keywords))
            ranking = Decimal(ranking) + Decimal(article.rank_score)
            create_userarticle(ranking, user_profile, article)

    return True


def create_article_from_feed_entry(feed_entry, rss_feed):
    article = Article()
    article.title = feed_entry.title
    article.summary = feed_entry.summary.replace('<br>','')
    article.url = feed_entry.link
    article.rss_feed = rss_feed
    article.rank_score = Decimal(rss_feed.rank_bonus) + SCORE_NEW_ARTICLE

    if hasattr(feed_entry, 'published'):
        article.date_published = feed_entry.published

    if "<img" in article.summary:
        article.rank_score += SCORE_ARTICLE_HAS_IMG

    if len(article.summary) > 150:
        article.rank_score += SCORE_ARTICLE_SUMMARY_LONGER_150C

    if Article.objects.filter(url=article.url).count() < 1:
        try:
            article.save()
        except IntegrityError:
            logging.error("Integrity Error caught")
        return article
    return None


def create_userarticle(ranking, user_profile, article):
    """ check if UserArticle exists, if not add to DB """
    if UserArticle.objects.filter(user_profile=user_profile, article=article).count() < 1:
        """ insert user article in db """

        new_item = UserArticle(user_profile=user_profile, article=article,
                               rank_score=ranking, date=article.date_published)
        new_item.save()
