function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring((name.length + 1)));
            }
        }
    }
    return cookieValue;
}
function setCookie(cname, cvalue) {
    document.cookie = cname + "=" + cvalue;
}

var csrftoken = getCookie('csrftoken');
function csrfSafeMethod(method) {
    // these HTTP methods do not require CSRF protection
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
function sameOrigin(url) {
    // test that a given url is a same-origin URL
    // url could be relative or scheme relative or absolute
    var host = document.location.host; // host + port
    var protocol = document.location.protocol;
    var sr_origin = '//' + host;
    var origin = protocol + sr_origin;
    // Allow absolute or scheme relative URLs to same origin
    return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
        (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
        !(/^(\/\/|http:|https:).*/.test(url));
}
$.ajaxSetup({
    beforeSend: function (xhr, settings) {
        if (!csrfSafeMethod(settings.type) && sameOrigin(settings.url)) {
            // Send the token to same-origin, relative URLs only.
            // Send the token only if the method warrants CSRF protection
            // Using the CSRFToken value acquired earlier
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        }
    }
});

function listCookies() {
    var theCookies = document.cookie.split(';');
    var aString = '';
    for (var i = 1; i <= theCookies.length; i++) {
        aString += i + ' ' + theCookies[i - 1] + "\n";
    }
    return aString;
}

//setTimeout(function(){
//
//                refreshArticles()
//                //window.location.href = '/';
//                $(window).scrollTop(0);
//}, 5000);


var selected = [];
var viewModel = null;
var observable_array = null;
var observable_array = ko.observableArray([]);

function removeAddsFromSummary() {
    $('img[alt=Feed-tw]').css("display", "none");
    $('img[alt=Feed-fb]').css("display", "none");
}


$(document).ready(function () {
    removeAddsFromSummary();

    $('.overlay-panel').on('click', function (event) {
        if ( $(event.target).is('.overlay-panel') || $(event.target).is('.overlay-panel-close')) {
            $('.overlay-panel').removeClass('is-visible');
            //if ($(event.target).is('.overlay-panel-close')) {

            $(window).on('beforeunload', function() {
                window.location.href = '/';
                $(window).scrollTop(0);
            });
            //}
            //event.preventDefault();
        }
    });




    $(window).resize(function () {
        updatePopup();
    });
    viewModel = new MyViewModel();
    ko.applyBindings(viewModel);


    var isFirstLogin = getCookie("first-login");
    if (isFirstLogin == "true") {
        displayTopicsPopup();
        setCookie("first-login", false);
    }
});


var MyViewModel = function () {
    this.teams = observable_array;
};


function displayTopicsPopup() {
    observable_array.removeAll();
    getTopicsForPopup();
    openTopicsPopup();
    updatePopup();
}


function getTopicsForPopup() {
    var count = 0;

    for(i=0;i=observable_array.length;i++){

        observable_array.pop();
    }
    $.ajax({
        url: "topics/",
        type: 'POST',
        success: function (data) {
            console.log(JSON.stringify(data));
            count++;
            $.each(data, function (k, v) {
                observable_array.push({name: k, id: count, isChecked: castStrToBool(v)})
            });
        },
        error: function (xhr, errmsg, err) {
            console.log("error: " + xhr.status + ":" + xhr.responseText);
        }
    });
}


function openTopicsPopup(event) {
    var options = {
        "backdrop": "static",
        "keyboard": "false"
    };
    $('#pref_dialog').modal(options);

}


function castStrToBool(str) {
    if (str.toLowerCase() == 'false') {
        return false;
    } else if (str.toLowerCase() == 'true') {
        return true;
    } else {
        return undefined;
    }
}


function closeTopicsPopup(event) {
    event.preventDefault();
    observable_array.removeAll();

    $('#pref_dialog').on('hidden.bs.modal', function () {
        $(this).removeData('bs.modal');
        window.location.href = '/';
    });
}


function selectUnselectAllTopicsBtn() {
    if (this.checked) {
        $('.checkboxListItems').each(function () {
            this.checked = true;
        });
    } else {
        $('.checkboxListItems').each(function () {
            this.checked = false;
        });
    }
}


function login() {
    // search for existing cookie "first-login"
    var isFirstLogin = getCookie("first-login");
    // if does not exist, create and set to "true"
    if (isFirstLogin == null) {
        setCookie("first-login", "true");
    }

    window.location.href = "/login";

}


function updatePopup() {
    var $popupContent = $("#popup-content");
    var top = "80px"; // Fixed offset
    var left = ($(window).width() - $popupContent.outerWidth()) / 2; // Center horizontal
    $popupContent.css({
        'top': top,
        'left': left
    });
}


function refreshArticles(selected) {
    $.ajax({
        url: 'me/',
        type: 'POST',
        data: {"save_changes": "1", "checkboxes": selected},
        success: function (data) {
            window.location.href = data['page'];
            console.log("success");
        },
        error: function (jqXhr, textStatus, errorThrown) {
            console.log(errorThrown);
        }
    });
}
function saveTopics() {
    $('#teamCheckboxList').find('input:checked').each(function () {
        selected.push($(this).attr('value'));
        console.log( $(this).attr('value'));
    });
    refreshArticles(selected);
    $('#pref_dialog').modal('hide')
}



function displayArticleInOverlay(event, id) {
    event.preventDefault();
    getArticleInfo(id);
    $('.overlay-panel').addClass('is-visible');

}


function getArticleInfo(id) {
    $('#spinner').show();

    $.ajax({

        url: "article_info/",
        type: 'POST',
        data: {article_id: id},
        success: function (data) {
            console.log(JSON.stringify(data));
            console.log("success: " + id);
            populateOverlayWithInfo(data['article_title'], data['article_content'],data['related_tweets'],data['article_link'],data['twitter_username']);

            $('#spinner').hide();

        },
        error: function (xhr, errmsg, err) {
            console.log("error: " + xhr.status + ":" + xhr.responseText);
        }

    });
}



function getTarget(event) {
    target = (typeof window.event === "undefined") ? event.target : window.event.srcElement;
    return target;
}


//function removeImages() {
//    var images = $('#article').find('img').map(function () {
//        return this;
//    });
//
//    $(images).each(function () {
//        var img = $(this);
//        if ((img.id() <51)){
//            img.css("display", "none")
//
//        }
//
//    });
//    console.log(images);
//}


function makeLinks() {
    $("#article-overlay-url").linky({
        urls: true,
    });
}


function insertArticleContent(title, article_text, article_link, twitter_username) {
    document.getElementById("article-overlay-heading").innerHTML = title;
    document.getElementById("article-overlay-paragraph").innerHTML = article_text;
    document.getElementById("article-overlay-url").innerHTML = "<a href=" + article_link + " target=" + "_blank" + ">" + "Link to article source @" + twitter_username + "</a>";
}


function populateOverlayWithInfo(title, article_text,related_tweets,article_link,twitter_username) {
    insertArticleContent(title, article_text, article_link, twitter_username);
    insertTwitterFeed(twitter_username);
    initTwitterFeed("script", "twitter-wjs");
    makeLinks();
    $(".overlay-panel-content").animate({ scrollTop: 0 }, "fast");

}


function insertTwitterFeed(twitter_username) {
    var twitterDiv = document.getElementById("twitter-widget");
    twitterDiv.innerHTML = '<a class="twitter-timeline"  href="https://twitter.com/ubuntu" data-widget-id="630845903130259456" data-screen-name="' + twitter_username + '"></a>';
}

function initTwitterFeed(elemName, id) {
    var script = document.getElementById(id);
    if (script) {
        script.remove();

    }
    var firstElem = document.getElementsByTagName(elemName)[0];

    var protocol = /^http:/.test(document.location) ? 'http' : 'https';
    script = document.createElement(elemName);

    script.id = id;

    script.src = protocol + "://platform.twitter.com/widgets.js";
    firstElem.parentNode.insertBefore(script, firstElem);

}
