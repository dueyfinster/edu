from django.shortcuts import render, redirect
from django.contrib.auth import logout
from django.http import HttpResponse
import os
import tweepy
from django.core.exceptions import ObjectDoesNotExist
from authomatic import Authomatic
from authomatic.adapters import DjangoAdapter
from .webapp_authproviders import CONFIG
from rest_framework import mixins, viewsets
from .models import Article, UserArticle, Job, Topic, Client, UserTopic
from .models import UserProfile
from .serializers import JobSerializer
from .db_utils import add_user_to_db
from .db_utils import get_articles_from_keyword
from .db_utils import get_keywords_from_article_title
from django.views.decorators.http import require_http_methods
from redis import Redis
from docker_django.apps.newsfast.ranking import filter_articles_for_user
from .topic_form import TopicForm
from .views import set_topics_and_articles_for_user

redis = Redis(host='redis', port=6379)
# TODO Probably Django secret key to go here?
authomatic = Authomatic(CONFIG, 'XXXX')

import logging
# Get an instance of a logger
logger = logging.getLogger(__name__)
version = os.environ['NEWSFAST_VERSION']


def home(request):
    # client_id = request.COOKIES.get('client_id', '12345')  # '12345' - default

    if 'twitter_id' not in request.session:  # User is not logged in
        # ids = UserArticle.objects.values_list('article_id', flat=True).order_by('-rank_score', 'date')[:10]
        ids = Article.objects.values_list('id', flat=True).order_by('date_published')[:10]
        feeds = Article.objects.filter(id__in=set(ids))
        response = render(request, 'home.html',
                          {'feeds': feeds, 'version': version, })
    else:  # logged in user
        twitter_id = request.session['twitter_id']

        ids = UserArticle.objects.values_list('article_id', flat=True).filter(
            user_profile__twitter_id=twitter_id).order_by('-rank_score', 'date')[:10]
        feeds = Article.objects.filter(id__in=set(ids))

        if feeds.count() < 1:
            ids = UserArticle.objects.values_list('article_id', flat=True).filter(
                user_profile__twitter_id=twitter_id).order_by('-rank_score', 'date')[:10]
            feeds = Article.objects.filter(id__in=set(ids))

        twitter_screen_name = ''
        # include twitter screen name if user logged in
        if request.session and 'twitter_screen_name' in request.session and \
                request.session['twitter_screen_name']:
            twitter_screen_name = request.session['twitter_screen_name']

        response = render(request, 'home.html',
                          {'feeds': feeds, 'version': version, 'twitter_screen_name': twitter_screen_name})

    # if client_id == '12345':
    #    client = Client()
    #    client.save()
    #    response.set_cookie('client_id', client.id)

    return response


def login(request):
    provider_name = 'tw'
    # We we need the response object for the adapter.
    response = HttpResponse()

    # Start the login procedure
    # this uses the authomatic library which can also be used for facebook etc
    # for twtter this will redirect user to twitter to authenticate app
    # login will then get called a 2nd time as the callback
    # TODO handle user rejecting the app when sent to twtter sign in
    result = authomatic.login(DjangoAdapter(request, response), provider_name)

    # If there is no result, the login procedure is still pending.
    # Don't write anything to the response if there is no result!
    if result:
        # If there is result,
        # the login procedure is over and we can write to response.
        response.write('<a href="..">Home</a>')

        if result.error:
            # Login procedure finished with an error.
            response.write(
                '<h2>Damn that error: {0}</h2>'.format(result.error.message))

        elif result.user:
            # Hooray, we have the user!

            # OAuth 2.0 and OAuth 1.0a provide only limited user data on login,
            # We need to update the user to get more info.
            if not (result.user.name and result.user.id):
                result.user.update()

            # If there are credentials (only by AuthorizationProvider),
            # we can _access user's protected resources.
            if result.user.credentials:

                # Each provider has it's specific API.
                if result.provider.name == 'tw':
                    # Insert twitter info to DB
                    kwargs = {'twitter_id': result.user.id,
                              'twitter_screen_name': result.user.name}
                    add_user_to_db(**kwargs)

                    # Keep the access token and secret for the session
                    # we will use this to setup tweepy
                    response.write('Your are logged in with Twitter.<br />')
                    response.write(result.user.credentials)
                    response.write(result.user.credentials.consumer_secret)

                    # Keep the access token and secret
                    # we will use this to setup tweepy
                    # See followers example for how to setup tweepy
                    request.session['twitter_access_token_key'] \
                        = result.user.credentials.token
                    request.session['twitter_access_token_key'] \
                        = result.user.credentials.token
                    request.session['twitter_id'] \
                        = result.user.id
                    request.session['twitter_screen_name'] = result.user.name

                    user_topic_count = UserTopic.objects.filter(user_profile__twitter_id=result.user.id).count()

                    if user_topic_count == 0:
                        return redirect('user')
                    else:
                        return redirect('home')

    return response

def logout_user(request):
    response = HttpResponse()
    logout(request)
    response.delete_cookie('client_id')
    response.delete_cookie('authomatic')
    response.delete_cookie('sessionid')
    response.delete_cookie('csrftoken')
    return redirect('home')


def followers(request):
    response = HttpResponse()

    auth = tweepy.OAuthHandler(CONFIG['tw']['consumer_key'],
                               CONFIG['tw']['consumer_secret'])
    auth.set_access_token(request.session['twitter_access_token_key'],
                          request.session['twitter_access_token_secret'])
    # So now that we have our OAuthHandler equipped
    # with an access token, we are ready for business:
    api = tweepy.API(auth)

    # Show all followes for the authenticated user
    for follower in api.followers():
        text = follower
        response.write(u'<h3>{0}</h3>'.format(text))
        response.write(u'Follower:')
    return response


@require_http_methods(["GET", "POST"])
def garry_user(request):
    if 'twitter_id' not in request.session:
        return redirect('login')

    response = HttpResponse()
    twitter_id = request.session['twitter_id']

    # Posting topics to database
    set_topics_and_articles_for_user(request, twitter_id)

    topics = Topic.objects.all()

    twitter_screen_name = ''

    # include twitter screen name if user logged in
    if request.session and 'twitter_screen_name' in request.session and \
            request.session['twitter_screen_name']:
        twitter_screen_name = request.session['twitter_screen_name']

    user_topics = None

    try:
        user_topics = UserTopic.objects.filter(user_profile__twitter_id=twitter_id)
    except ObjectDoesNotExist:
        logging.error("No topics for this user")

    response = render(request, 'garry_user_page.html',
                      {'topics': topics, 'user_topics': user_topics,
                       'version': version, 'form': TopicForm(),
                       'twitter_screen_name': twitter_screen_name})
    return response


def keywords(request):
    response = HttpResponse()
    article_set = Article.objects.filter(keywords_extracted=True)
    for article in article_set:
        keywords = get_keywords_from_article_title(article.id)
        logger.error(keywords)
        response.write(u'<h3>{0}</h3>'.format(keywords))
    return response


def articles(request):
    response = HttpResponse()
    keyword_set = redis.smembers('kw:title')
    for keyword in keyword_set:
        articles = get_articles_from_keyword(keyword)
        response.write(u'<h3>{0}</h3>'.format(articles))
    return response


class JobViewSet(mixins.CreateModelMixin,
                 mixins.ListModelMixin,
                 mixins.RetrieveModelMixin,
                 viewsets.GenericViewSet):
    """
    API endpoint that allows jobs to be viewed or created.
    """
    queryset = Job.objects.all()
    serializer_class = JobSerializer
