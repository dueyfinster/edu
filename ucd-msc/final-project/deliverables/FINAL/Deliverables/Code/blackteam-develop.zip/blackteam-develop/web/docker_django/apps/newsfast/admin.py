from django.contrib import admin
from .models import Article, Client, Job, KeywordDB, RSSFeed, NLPTechKeywordList, \
    Topic, UserTopic, UserProfile, UserArticle, TrainingSet, SystemConfig, Synonym, OffensiveWord,TwitterFollower


class RSSFeedAdmin(admin.ModelAdmin):
    list_display = ['name', 'twitter_username', 'rank_bonus', 'url']
    search_fields = ['name', 'twitter_username', 'url']


class TopicAdmin(admin.ModelAdmin):
    list_display = ['name', 'has_synonym']
    search_fields = ['name', 'has_synonym']
    

class OffensiveWordsAdmin(admin.ModelAdmin):
    list_display = ['word']
    search_fields = ['word']


class SynonymsAdmin(admin.ModelAdmin):
    list_display = ['first_word', 'second_word']
    search_fields = ['first_word', 'second_word']


class UserTopicAdmin(admin.ModelAdmin):
    model = UserTopic
    list_display = ['get_user', 'get_topic', 'date_added']
    search_fields = ['user_profile__twitter_id', 'topic_name__name']

    def get_user(self, obj):
        return obj.user_profile.twitter_id

    def get_topic(self, obj):
        return obj.topic_name.name


class TechKeywordListAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


class SystemConfigAdmin(admin.ModelAdmin):
    list_display = ['num_articles_store', 'num_latest_display', 'num_personal_display', 'mix_articles']
    search_fields = ['num_articles_store', 'num_latest_display', 'num_personal_display', 'mix_articles']


class UserAdmin(admin.ModelAdmin):
    list_display = ['twitter_id', 'twitter_screen_name', 'twitter_name',
                    'email_address', 'facebook_id', 'linkedin_id']
    search_fields = ['twitter_id', 'twitter_screen_name', 'twitter_name',
                     'email_address', 'facebook_id', 'linkedin_id']


class ArticleAdmin(admin.ModelAdmin):
    model = Article
    list_display = ['id', 'title', 'url', 'summary', 'rank_score', 'date_published', 'keywords_extracted','get_rss_feed']
    search_fields = ['title', 'url', 'summary', 'date_published', 'keywords_extracted']

    def get_rss_feed(self, obj):
        return obj.rss_feed.name


class UserArticleAdmin(admin.ModelAdmin):
    model = UserArticle
    list_display = ['get_user','get_article_id', 'get_article', 'rank_score', 'date']
    search_fields = ['user_profile__twitter_id', 'article__title', 'rank_score', 'date']

    def get_user(self, obj):
        return obj.user_profile.twitter_id

    def get_article(self, obj):
        return obj.article.title

    def get_article_id(self, obj):
        return obj.article.id

    get_article.admin_order_field = 'id'  # Allows column order sorting


class KeywordDBAdmin(admin.ModelAdmin):
    list_display = ['db_selected']
    search_fields = ['db_selected']


class ClientAdmin(admin.ModelAdmin):
    model = Client
    list_display = ['id', 'date']
    search_fields = ['id', 'date']


class JobAdmin(admin.ModelAdmin):
    list_display = ['type', 'status', 'created_at', 'updated_at', 'argument',
                    'result']
    search_fields = ['type', 'status', 'created_at', 'updated_at', 'argument',
                     'result']

class TrainingSetAdmin(admin.ModelAdmin):
    model = TrainingSet
    list_display = ['get_user', 'get_article', 'keyword']
    search_fields = ['user__twitter_id', 'article__title', 'keyword']

    def get_user(self, obj):
        return obj.user.twitter_id

    def get_article(self, obj):
        return obj.article.id

class TwitterFollowerAdmin(admin.ModelAdmin):
    model = TwitterFollower
    list_display = ['name', 'hash_tag_name']
    search_fields = ['name', 'hash_tag_name']

# Register your models here.
admin.site.register(RSSFeed, RSSFeedAdmin)
admin.site.register(OffensiveWord, OffensiveWordsAdmin)
admin.site.register(Synonym, SynonymsAdmin)
admin.site.register(Topic, TopicAdmin)
admin.site.register(UserTopic, UserTopicAdmin)
admin.site.register(UserProfile, UserAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(UserArticle, UserArticleAdmin)
admin.site.register(KeywordDB, KeywordDBAdmin)
admin.site.register(NLPTechKeywordList, TechKeywordListAdmin)
admin.site.register(Client, ClientAdmin)
admin.site.register(Job, JobAdmin)
admin.site.register(TrainingSet, TrainingSetAdmin)
admin.site.register(SystemConfig, SystemConfigAdmin)
admin.site.register(TwitterFollower, TwitterFollowerAdmin)