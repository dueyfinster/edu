from django.conf.urls import url, include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from rest_framework import routers

from . import views
from docker_django import settings

router = routers.DefaultRouter()
router.register(r'jobs', views.JobViewSet)

urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^login/$', views.login, name='login'),
    url(r'^logout/$', views.logout_user, name='logout'),
    url(r'^me/$', views.user, name='user'),
    url(r'^(?:landing.html)?$', views.landing, name="landing"),
    url(r'^skip/$', views.skip, name='skip'),
    url(r'^topics/$', views.topics, name='topics'),
    url(r'^article_info/$', views.article_info, name='article_info'),
    url(r'^tweets/$', views.get_related_tweets, name='get_related_tweets'),
    url(r'^LAR', include(router.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
urlpatterns += staticfiles_urlpatterns()
