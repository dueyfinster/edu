# Building Docker Images for Blackteam

Username: blackteam
Password: kilkenny
E-mail: neil+ucd@grogan.ie


## To build the image:
1. Login to docker (details above): ``$ docker login``
2. Update the requirements file ``<path/to/repo>/web/requirements.txt``
3. Build the image (make sure your in this directory): ``$ ./build.sh``
4. Submit the image to docker hub: ``docker push blackteam/blackteam``
