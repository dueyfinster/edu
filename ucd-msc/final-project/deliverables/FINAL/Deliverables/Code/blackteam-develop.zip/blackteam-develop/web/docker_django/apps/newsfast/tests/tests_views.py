from django.test import TestCase, Client  # noqa
from django.core.urlresolvers import reverse


class ViewTests(TestCase):
    def test_home(self):
        client = Client()
        response = client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

