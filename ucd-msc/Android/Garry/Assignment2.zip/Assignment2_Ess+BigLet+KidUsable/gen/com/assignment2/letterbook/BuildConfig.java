/** Automatically generated file. DO NOT MODIFY */
package com.assignment2.letterbook;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}