/**
 * COMP30510 - Mobile Application Development (Android) Online 
 * Student: Garry Davitt 
 * Student ID:13205364 
 * Course: M.Sc Computer Science (Software Eng.Stream) 
 * Lecturer: Dr. Abraham Campbell
 */

package android.app.assignment1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class ComposeMessageActivity extends Activity {
	private EditText toEditText;
	private EditText fromEditText;
	private EditText ccEditText;
	private EditText messageEditText;
	private EditText subjectEditText;
	private EditText bccEditText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.linear);
		enableEditing(true);
		setTitle(R.string.compose_activity_label);
		findFields();
		final Button sendButton = (Button) findViewById(R.id.sendButtonId);
		sendButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				sendMessage(v);
			}
		});

		final Button clearButton = (Button) findViewById(R.id.clearButtonId);
		clearButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				clear();
			}

		});
	}

	@Override
	public void onResume() {
		super.onResume();
		findFields();
		loadData();
		enableEditing(true);
	}

	@Override
	public void onPause() {
		super.onPause();
		findFields();
		saveData();
		enableEditing(true);
	}

	private void clear() {
		ViewGroup group = (ViewGroup) findViewById(R.id.layoutId);
		for (int i = 0, count = group.getChildCount(); i < count; ++i) {
			View view = group.getChildAt(i);
			if (view instanceof EditText) {
				((EditText) view).setText("");
			}
		}
	}

	private void enableEditing(boolean isEnabled) {
		ViewGroup group = (ViewGroup) findViewById(R.id.layoutId);
		for (int i = 0, count = group.getChildCount(); i < count; ++i) {
			View view = group.getChildAt(i);
			if (view instanceof EditText) {
				((EditText) view).setEnabled(isEnabled);
			}
		}
	}

	/** Called when the user clicks the Send button */
	public void sendMessage(View view) {
		Log.w("myApp", "send was pressed");

		Intent intent = new Intent(this, ReadMessageActivity.class);
		findFields();
		saveData();
		startActivity(intent);
	}

	private void saveData() {
		SharedPreferences sharedPreferences = PreferenceManager
				.getDefaultSharedPreferences(this);
		Editor editor = sharedPreferences.edit();
		editor.putString("from", fromEditText.getText().toString());
		editor.putString("to", toEditText.getText().toString());
		editor.putString("cc", ccEditText.getText().toString());
		editor.putString("bcc", bccEditText.getText().toString());
		editor.putString("subject", subjectEditText.getText().toString());
		editor.putString("message", messageEditText.getText().toString());
		editor.commit();
	}

	private void findFields() {
		fromEditText = (EditText) findViewById(R.id.fromId);
		toEditText = (EditText) findViewById(R.id.toId);
		ccEditText = (EditText) findViewById(R.id.ccId);
		bccEditText = (EditText) findViewById(R.id.bccId);
		subjectEditText = (EditText) findViewById(R.id.subjectId);
		messageEditText = (EditText) findViewById(R.id.messageId);
	}

	private void loadData() {
		SharedPreferences sharedPreferences = PreferenceManager
				.getDefaultSharedPreferences(this);
		findFields();
		fromEditText.setText(sharedPreferences.getString("from", null));
		toEditText.setText(sharedPreferences.getString("to", null));
		ccEditText.setText(sharedPreferences.getString("cc", null));
		bccEditText.setText(sharedPreferences.getString("bcc", null));
		subjectEditText.setText(sharedPreferences.getString("subject", null));
		messageEditText.setText(sharedPreferences.getString("message", null));
	}

}
