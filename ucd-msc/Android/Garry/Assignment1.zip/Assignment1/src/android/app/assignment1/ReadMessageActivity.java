/**
 * COMP30510 - Mobile Application Development (Android) Online
 * Student: Garry Davitt
 * Student ID:13205364
 * Course: M.Sc Computer Science (Software Eng. Stream)
 * Lecturer: Dr. Abraham Campbell 
 */

package android.app.assignment1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class ReadMessageActivity extends Activity {

	private EditText fromEditText;
	private EditText toEditText;
	private EditText ccEditText;
	private EditText messageEditText;
	private EditText bccEditText;
	private EditText subjectEditText;
	private Button sendButton;
	private Button clearButton;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.linear);
		removeButtonsAndBcc();

		ViewGroup linearLayout = (ViewGroup) findViewById(R.id.layoutId);
		LinearLayout.LayoutParams rightGravityParams = new LinearLayout.LayoutParams(
				LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		rightGravityParams.gravity = Gravity.RIGHT;

		Button backButton = new Button(this);
		backButton.setText("Back");
		linearLayout.addView(backButton, rightGravityParams);

		backButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View paramView) {
				onBackPressed();
			}
		});
		loadData();
		enableEditing(false);

	}

	@Override
	public void onResume() {
		super.onResume();
		findFields();
		loadData();
		enableEditing(false);
	}

	@Override
	public void onPause() {
		super.onPause();
		findFields();
		loadData();
		enableEditing(false);
	}

	private void removeButtonsAndBcc() {
		bccEditText = (EditText) findViewById(R.id.bccId);
		bccEditText.setVisibility(View.GONE);
		sendButton = (Button) findViewById(R.id.sendButtonId);
		sendButton.setVisibility(View.GONE);
		clearButton = (Button) findViewById(R.id.clearButtonId);
		clearButton.setVisibility(View.GONE);
	}

	private void loadData() {
		SharedPreferences sharedPreferences = PreferenceManager
				.getDefaultSharedPreferences(this);
		findFields();
		fromEditText.setText(sharedPreferences.getString("from", null));
		toEditText.setText(sharedPreferences.getString("to", null));
		ccEditText.setText(sharedPreferences.getString("cc", null));
		bccEditText.setText(sharedPreferences.getString("bcc", null));
		subjectEditText.setText(sharedPreferences.getString("subject", null));
		messageEditText.setText(sharedPreferences.getString("message", null));
	}

	private void enableEditing(boolean isEnabled) {
		ViewGroup group = (ViewGroup) findViewById(R.id.layoutId);
		for (int i = 0, count = group.getChildCount(); i < count; ++i) {
			View view = group.getChildAt(i);
			if (view instanceof EditText) {
				((EditText) view).setEnabled(isEnabled);
			}
		}
	}

	private void findFields() {
		fromEditText = (EditText) findViewById(R.id.fromId);
		toEditText = (EditText) findViewById(R.id.toId);
		ccEditText = (EditText) findViewById(R.id.ccId);
		bccEditText = (EditText) findViewById(R.id.bccId);
		subjectEditText = (EditText) findViewById(R.id.subjectId);
		messageEditText = (EditText) findViewById(R.id.messageId);
	}

}